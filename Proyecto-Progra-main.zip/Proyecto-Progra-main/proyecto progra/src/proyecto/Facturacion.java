package proyecto;
//modulo factura
import javax.swing.JOptionPane;
public class Facturacion {
       static int gan;
        static int gan2=0;
public static void Factura() {
    //variables factura 
        byte Libro;
        int ap3 = -1, i, opcion, p = 0, NumFactura=000, buscar, eliminar;
        boolean existe = false;
        boolean encontrar = false;
        String LibroCual= " ";
        String aux = "";
        int PrecioAlquiler = 0;
        int[] Numero = new int[5];
        String[] LibroAlq = new String[5];
        String[] NombreCliente = new String[5];
        String[] ApellidoCliente = new String[5];
        String[] Dirreccion = new String[5];
        String[] Fecha = new String[5];
        int [] Precio= new int[5];
        double[] telefono = new double[5];
        String[] estado = new String[5];
        // menu facturas
        do {
            opcion = Integer.parseInt(JOptionPane.showInputDialog("Menu"
                    + "\n1.-Alquilar libros"
                    + "\n2.-Ver Facturas"
                    + "\n3.-Anular Facturas"
                    + "\n4.-Salida"));
            switch (opcion) {
                case 1:
                     // llenar datos factura 
                    Libro=Byte.parseByte(JOptionPane.showInputDialog(
                            "          Libros disponibles para alquilar  \n"
                            + "1    La Biblia(religiones judía y cristiana, transmite la palabra de Dios.) Precio de alquiler: ₡5500\n"
                            + "2    El Señor de los Anillos( novela de fantasía épica) Precio de alquiler: ₡3900\n"
                            + "3    El Código Da Vinci(novela de misterio) Precio de alquiler: ₡5900\n"
                            + "4    Piense y hágase rico( el método más famoso y efectivo para hacer dinero) Precio de alquiler: ₡4900\n"        
                            + "Elija una opción"));                       
                    if (ap3 != 4) {
                        encontrar = false;
                        NumFactura = NumFactura+001;
                        JOptionPane.showMessageDialog(null, "El numero de su factura es: "+NumFactura);
                        for (i = 0; i <= ap3; i++) {
                            if (NumFactura == Numero[ap3]) {
                                encontrar = true;
                            }  
                        }
                        if (encontrar == false) {
                            if (Libro==1){
                                LibroCual="La Biblia(religiones judía y cristiana, transmite la palabra de Dios.)";
                                PrecioAlquiler=5500;
                                gan2=5500;
                            }
                            if (Libro==2){
                                LibroCual="El Señor de los Anillos( novela de fantasía épica)";
                                PrecioAlquiler=3900;
                                gan2=3900;
                            }     
                            if (Libro==3){
                                LibroCual="El Código Da Vinci(novela de misterio)";
                                PrecioAlquiler=5900;
                                gan2=5900;
                            }    
                            if (Libro==4){
                                LibroCual="Piense y hágase rico( el método más famoso y efectivo para hacer dinero)";
                                PrecioAlquiler=4900;
                                gan2=4900;
                            }
                            ap3++;
                            estado[ap3]="Activa";
                            LibroAlq[ap3]=LibroCual;
                            Precio[ap3]= PrecioAlquiler;
                            Numero[ap3] = NumFactura;
                            NombreCliente[ap3] = JOptionPane.showInputDialog("Ingrese el nombre del cliente:");
                            ApellidoCliente[ap3] = JOptionPane.showInputDialog("Ingrese los apellidos del cliente");
                            Dirreccion[ap3] = JOptionPane.showInputDialog("Ingrese la direccion del cliente: ");
                            telefono[ap3] = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el numero de telefono del cliente: "));
                            Fecha[ap3] = JOptionPane.showInputDialog("Ingrese la fecha de hoy: ");
                            gan=gan2+gan;
                            JOptionPane.showMessageDialog(null, "-----------------------------------------------------\n"+
                                    Fecha[ap3]+"\n Estado de factura:"+estado[ap3] +"\n Numero de Factura: " + Numero[ap3] + "\nNombre del cliente: " + NombreCliente[ap3] +" " + ApellidoCliente[ap3]+ "\n Dirreccion Del cliente: " + Dirreccion[ap3]+
                                                "\n El libro que alquilo es: "+LibroAlq[ap3]+"\n Monto a pagar: "+ Precio[ap3]+"\n -----------------------------------------------------\n");
                        }
                        else {
                            JOptionPane.showMessageDialog(null, "Los datos de la factura digitados ya existen");
                        }

                    } else {
                        JOptionPane.showMessageDialog(null, "No Hay Espacio");
                    }
                    break;
                case 2:
                    //ver facturas 
                    if (ap3 != -1) {
                        aux = "";
                        for (i = 0; i <= ap3; i++) {
                            aux = aux +"----------------------------------------------------------------------------------------------------------\n"+Fecha[i]+ "\nEstado de factura:"+estado[i] +
                                    "\nNumero de Factura: " + Numero[i] + "\nNombre del cliente: " + NombreCliente[i] +" " + ApellidoCliente[i]+ "\nDirreccion Del cliente: " + Dirreccion[i]+
                                    "\nEl libro que alquilo es: "+LibroAlq[i]+"\nMonto a pagar: "
                                    + Precio[i]+"\n ----------------------------------------------------------------------------------------------------------\n";

                        }
                        JOptionPane.showMessageDialog(null, "Consulta General\n\n " + aux);

                    }
                    else {
                        JOptionPane.showMessageDialog(null, "No hay Datos");
                    }
                    break;
                case 3:
                    //anular facturas 
                if (ap3 != -1) {
                        existe = false;
                        buscar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su numero de factura"));
                        for (i = 0; i <= ap3; i++) {
                            if (buscar == (Numero[i])) {
                                existe = true;
                                estado[ap3] = "Anulada";
                            }
                        }
                        if (existe == true) {
                            JOptionPane.showMessageDialog(null, "Eleccion Modificada  ");
                        } else {
                            JOptionPane.showMessageDialog(null, "El Empleado/Cliente " + buscar + " No Existe");
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "No Hay Datos");
                    }
                case 4:
                    break;
            }
            //salir
        } while (opcion != 4);
    }
//modulo cajas 
public void cajas(){
JOptionPane.showMessageDialog(null, "La ganancia total: "+gan);

}
  }