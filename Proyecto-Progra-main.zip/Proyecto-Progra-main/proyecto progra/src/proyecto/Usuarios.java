package proyecto;
public class Usuarios {
    //variables para usuarios 
    private String nombre;
    private String apellidos;
    private String nickname;
    private String contraseña;
    private String estado;
    int length;    
        public Usuarios(){
        this.nombre="";
        this.apellidos="";
        this.nickname="";
        this.contraseña="";
        this.estado="Activo";
    } 
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getApellidos() {
        return apellidos;
    }
    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }
    public String getNickname() {
        return nickname;
    }
    public void setNickname(String nickname) {
        this.nickname = nickname;
    }
    public String getContraseña() {
        return contraseña;
    }
    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }
    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
}}