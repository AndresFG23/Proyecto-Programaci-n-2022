package proyecto;
import javax.swing.JOptionPane;
public class RegistrodeUsuarios {
//Menu de registro de usuarios 
    public void menuUsuarios(){
        //solicitar cuantos usurios desea registar
    int DatosUsuaros=2;
        
    //sistema de solicitar tamaño de array    
    //int DatosUsuaros=Integer.parseInt(JOptionPane.showInputDialog
    // (null,"Digite cuantos usuarios desea registar: "));
    Usuarios a[]=new Usuarios[DatosUsuaros];

        int x;
       byte op=0;
   do{
      op=Byte.parseByte(JOptionPane.showInputDialog(
     "          Menú de Usuarios  \n"
    + "1    -Registrar un Usuario\n"
    + "2    -Ver usuarios\n"
    + "3    -Buscar usuarios\n"
    + "4    -Inactivar usuarios\n"        
    + "5    -Regresar al menu principal\n"
    + "Elija una opción"));
      switch(op){
         case 1:
     //datos solicitados para usuarios        
     for ( x=0; x<DatosUsuaros;x++){   
        Usuarios e=new Usuarios();
            e.setNombre(JOptionPane.showInputDialog
                (null,"Digite su nombre:"));
            e.setApellidos(JOptionPane.showInputDialog
                (null, "Digite su apellidos: "));
            e.setNickname(JOptionPane.showInputDialog
                (null, "Digite un nickname: "));
            e.setContraseña(JOptionPane.showInputDialog
                (null,"Digite su contraseña:"));
            a[x]=e;
     }  
            break;
         case 2: 
             //mostrar arreglo
            String s="";
            for(x=0;x<a.length;x++){
                 s=s+"  -Nombre: "+a[x].getNombre()+"  -Apellido:"+a[x].getApellidos()+"  -Usuario: "+
                 a[x].getNickname()+"  -Estado :"+a[x].getEstado()+" "+"\n";
      }
      JOptionPane.showMessageDialog(null,"Usuarios registrados\n"+s);
            break;  
         case 3:
             //buscar usuraio
      int encontrados=0;
      String ape1;
      ape1=JOptionPane.showInputDialog(null,"Digite los apellidos de la persona:");
      for(x=0;x<a.length;x++){
          if(ape1.equals(a[x].getApellidos())){
             JOptionPane.showMessageDialog(null,"Datos de la persona "+
                     "\n El Usuario: "+a[x].getNickname()+"\n Nombre:  "+
                      a[x].getNombre()+"\n Apellidos: "+a[x].getApellidos()
                      +"\n Estado: "+a[x].getEstado()+" ");
             encontrados=1;
          }
      }      if(encontrados==0){
         JOptionPane.showMessageDialog(null,
                 "El Usuario no fue encontrado");
      }  
      break;
         case 4:
             //inactivar usuario
      int encontrado=0;
      String ape2;
      ape2=JOptionPane.showInputDialog(null,"Digite los apellidos de la persona:");
      for(x=0;x<a.length;x++){
          if(ape2.equals(a[x].getApellidos())){
              a[x].setEstado("Inactivo");
             JOptionPane.showMessageDialog(null,
                     "El Usuario: "+a[x].getNickname()+" bajo el nombre de:  "+
                      a[x].getNombre()+" "+a[x].getApellidos()+"\n cambio a estado: "+a[x].getEstado()+" ");
             encontrado=1;
          }
      }
      if(encontrado==0){
         JOptionPane.showMessageDialog(null,
                 "El Usuario no fue encontrado por lo que no se puede Inactivar");
      } 
            break;
         case 5:
             break;
         default:
            JOptionPane.showMessageDialog(null, "Opción no valida");
            break;  
      }
   }while(op!=5); 
    }
}
