package proyecto;
public class Main {
   public static void main(String[] args) {
     Bienvenida Bienvenida01=new Bienvenida();
     Bienvenida01.Bienvenida();
      Menu Menu01=new Menu();
      Menu01.Menu();
     Bienvenida01.gracias();      
   }
}