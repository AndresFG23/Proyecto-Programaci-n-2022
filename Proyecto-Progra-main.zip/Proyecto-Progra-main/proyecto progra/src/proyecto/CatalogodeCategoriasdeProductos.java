package proyecto;

import javax.swing.JOptionPane;

public class CatalogodeCategoriasdeProductos{
    public static void catalogoCategorias() {
        //variables catalogo productos
        int ap1 = -1, i, op, p = 0, NumBuscar, buscar, eliminar;
        boolean existe = false;
        boolean encontrar = false;
        String aux = "";
        int[] Numero = new int[5];
        String[] NombreCategoria = new String[5];
        int[] precioU = new int[5];
        String[] caracteristicas = new String[5];
        String[] ActivoInactivo = new String[5];
        String[] categoria = new String[5];
        do {
            op = Integer.parseInt(JOptionPane.showInputDialog("          Menú de productos  \n"
                    + "\n1.    -Agregar un nuevo producto"
                    + "\n2.    -Consulta General"
                    + "\n3.    -Busqueda por nombre de producto"
                    + "\n4.    -Editar producto ingresado"
                    + "\n5.    -Borrar datos de producto ingresados"
                    + "\n6.    -Regresar al menu principal"));
            switch (op) {
                case 1:
                    //llenar catalogo de productos 
                    if (ap1 != 4) {
                        encontrar = false;
                        NumBuscar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el codigo del producto: "));
                        for (i = 0; i <= ap1; i++) {
                            if (NumBuscar == Numero[ap1]) {
                                encontrar = true;
                            }
                        }
                        if (encontrar == false) {
                            ap1++;
                            Numero[ap1] = NumBuscar;
                            NombreCategoria[ap1] = JOptionPane.showInputDialog("Ingrese el nombre del producto:");
                            precioU[ap1] = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el precio unitario del producto: "));
                            caracteristicas[ap1] = JOptionPane.showInputDialog("Ingrese las características del producto: ");  
                            categoria[ap1] = JOptionPane.showInputDialog("Ingrese la categoria del producto: ");
                            ActivoInactivo[ap1] = "Activo";
                        }
                        else {
                            JOptionPane.showMessageDialog(null, "El producto digitado ya existe");
                        }

                    } else {
                        JOptionPane.showMessageDialog(null, "No Hay Espacio");
                    }
                    break;
                case 2:
                    // ver catalogo producto
                    if (ap1 != -1) {
                        aux = "";
                        for (i = 0; i <= ap1; i++) {
                            aux = aux + "\nCodigo del producto: " + Numero[i] + "\nNombre del producto: " + NombreCategoria[i] + "\nPrecio Unitario del producto: " + precioU[i] + "\nEstado del producto: " + ActivoInactivo[i] 
                                    + "\nCaracteristicas del producto: " + caracteristicas[ap1]+"\nCategoria: "+categoria[i]+"\n ----------------------------------------------------------------------------------------------------------\n";
                        }
                        JOptionPane.showMessageDialog(null, "Consulta General\n\n " + aux);
                    }
                    else {
                        JOptionPane.showMessageDialog(null, "No hay Datos");
                    }
                    break;
                case 3:
                    //buscar catalogo libros 
                    if (ap1 != -1) {
                        existe = false;
                        buscar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el codigo del producto: "));

                        for (i = 0; i <= ap1; i++) {
                            if (buscar == (Numero[i])) {
                                existe = true;
                                JOptionPane.showMessageDialog(null, "\nCodigo del producto: "  + Numero[i] + "\nNombre del producto: " + NombreCategoria[i] + "\nPrecio Unitario del producto: " + precioU[i] + "\nEstado del producto" + ActivoInactivo[i] 
                                    + "\nCaracteristicas del producto" + caracteristicas[ap1]+"\nCategoria: "+categoria[i]);
                            }
                        }
                        if (existe == false) {
                            JOptionPane.showMessageDialog(null, "El codigo del producto " + buscar + " No Existe");
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "No hay Datos");
                    }

                    break;
                case 4:
                    
                    //editar productos del catalogo
                    if (ap1 != -1) {
                        existe = false;
                        buscar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el codigo del producto"));
                        for (i = 0; i <= ap1; i++) {
                            if (buscar == (Numero[i])) {
                                existe = true;            
                                NombreCategoria[i] = JOptionPane.showInputDialog("Ingrese el nombre del producto:");
                                precioU[i] = Integer.parseInt(JOptionPane.showInputDialog("Edite el nuevo precio Unitario del producto: "));
                                caracteristicas[i] = (JOptionPane.showInputDialog("Edite las características del producto: "));
                                categoria[ap1] = JOptionPane.showInputDialog("Edite la categoria del producto: ");
                                ActivoInactivo[i] =  "Activo";                            
                            }
                        }
                        if (existe == true) {
                            JOptionPane.showMessageDialog(null, "Eleccion Modificada  ");
                        } else {
                            JOptionPane.showMessageDialog(null, "El Codigo del producto " + buscar + " No Existe");
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "No Hay Datos");
                    }
                    break;
                case 5:
                     //anular productos del catalogo
                    if (ap1 != -1) {
                        existe = false;
                        buscar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el codigo del producto"));
                        for (i = 0; i <= ap1; i++) {
                            if (buscar == (Numero[i])) {
                                existe = true;
                                NombreCategoria[i] = "";
                                precioU[i] = 0;
                                caracteristicas[i]= "";
                                ActivoInactivo[i] =  "";
                                categoria[i]=  "";
                                caracteristicas[i]="";
                            }
                        }
                        if (existe == true) {
                            JOptionPane.showMessageDialog(null, "Eleccion Modificada  ");
                        } else {
                            JOptionPane.showMessageDialog(null, "El producto " + buscar + " No Existe");
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "No Hay Datos");
                    }
                    break;
                case 6:
                    break;
            }
            //regresar menu principal
        } while (op != 6);
    }
  }