package proyecto;

import javax.swing.JOptionPane;

public class CatalogoEmpleados {
 public static void catalogo() {
     //variables catalogo
        int ap2 = -1, i, op, p = 0, NumBuscar, buscar, eliminar,y=1;
        boolean existe = false;
        boolean encontrar = false;
        String aux = "";
        int[] Numero = new int[5];
        String[] Nombre = new String[5];
        int[] Edad = new int[5];
        int[] telefono = new int[5];
        String[] activoInactivo = new String[5];
        String[] EmpleadosClientes = new String[5];
        String[] ciudad = new String[5];
        String[] direccion = new String[5];  
        String[] correo = new String[5];
        do {
            //menu catalogo
            op = Integer.parseInt(JOptionPane.showInputDialog("          Menú de Catalogo Empleados  \n"
                    + "\n1.    -Agregar un nuevo Empleados/Clientes"
                    + "\n2.    -Consulta General"
                    + "\n3.    -Busqueda por Numero de registro de Empleados/Clientes"
                    + "\n4.    -Editar Empleados/Clientes ingresado"
                    + "\n5.    -Borrar datos de Empleados/Clientes ingresados"
                    + "\n6.    -Regresar al menu principal"));
            switch (op) {
                case 1:
                    //llenar datos catalogo
                    if (ap2 != 4) {
                        encontrar = false;
                        NumBuscar = y++;
                        for (i = 0; i <= ap2; i++) {
                            if (NumBuscar == Numero[ap2]) {
                                encontrar = true;
                            }
                        }
                        if (encontrar == false) {
                            ap2++;
                            Numero[ap2]=NumBuscar;
                            JOptionPane.showMessageDialog(null, "Numero de registro: "+ Numero[ap2] );
                            Nombre[ap2] = JOptionPane.showInputDialog("Ingrese su nombre y apellidos:");
                            Edad[ap2] = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su edad: "));
                            telefono[ap2] = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su numero de telefono: "));
                            ciudad[ap2] = JOptionPane.showInputDialog("Ingrese su ciudad: ");
                            direccion[ap2] = JOptionPane.showInputDialog("Ingrese su direccion: ");
                            correo[ap2] = JOptionPane.showInputDialog("Ingrese su correo: ");
                            activoInactivo[ap2] = "Activo";
                            EmpleadosClientes[ap2] = JOptionPane.showInputDialog("Ingrese si es Cliente o Empleado:");
                        }
                        else {
                            JOptionPane.showMessageDialog(null, "El Empleado/Cliente digitado ya existe");
                        }

                    } else {
                        JOptionPane.showMessageDialog(null, "No Hay Espacio");
                    }
                    break;
                case 2:
                    // mostrar catalogo
                    if (ap2 != -1) {
                        aux = "";
                        for (i = 0; i <= ap2; i++) {
                            aux = aux + "\nNumero de registro: " + Numero[i] + "\nNombre: " + Nombre[i] + "\nEdad : " + Edad[i] + "\nEstado:" + activoInactivo[i]
                                    +"\nTelefono: "+telefono[i]+"\nCorreo: "+correo[i]+"\n Ciudad: "+ciudad[i]+"\nDireccion: "+direccion[i]+"\nEs: "+EmpleadosClientes[i]
                                    +"\n ----------------------------------------------------------------------------------------------------------\n";

                        }
                        JOptionPane.showMessageDialog(null, "Consulta General\n\n " + aux);

                    }
                    else {
                        JOptionPane.showMessageDialog(null, "No hay Datos");
                    }
                    break;
                case 3:
                    //buscar en el catalogo
                    if (ap2 != -1) {
                        existe = false;
                        buscar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el numero de registro: "));

                        for (i = 0; i <= ap2; i++) {
                            if (buscar == (Numero[i])) {
                                existe = true;
                                JOptionPane.showMessageDialog(null, "\nNumero de registro: " + Numero[i] + "\nNombre: " + Nombre[i] + "\nEdad: " + Edad[i] + "\nEstado:" + activoInactivo[i]
                                    +"\nTelefono: "+telefono[i]+"\nCorreo: "+correo[i]+"\n Ciudad: "+ciudad[i]+"\nDireccion: "+direccion[i]+"\nEs: "+EmpleadosClientes[i]+"\n");
                            }
                        }
                        if (existe == false) {
                            JOptionPane.showMessageDialog(null, "El Numero de registro  " + buscar + " No Existe");
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "No hay Datos");
                    }

                    break;
                case 4:
                    // editar catalogo
                    if (ap2 != -1) {
                        existe = false;
                        buscar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el numero de registro"));
                        for (i = 0; i <= ap2; i++) {
                            if (buscar == (Numero[i])) {
                                Nombre[i] = JOptionPane.showInputDialog("Edite su nombre y apellidos");
                                Edad[i] = Integer.parseInt(JOptionPane.showInputDialog("Edite la  edad: "));
                                telefono[i] = Integer.parseInt(JOptionPane.showInputDialog("Edite el numero de telefono: "));
                                correo[i] = JOptionPane.showInputDialog("Edite su correo: ");
                                ciudad[i] = JOptionPane.showInputDialog("Edite su ciudad: ");
                                direccion[i] = JOptionPane.showInputDialog("Edite su direccion: ");                               
                                activoInactivo[i] = "Activo";  
                                EmpleadosClientes[i] = JOptionPane.showInputDialog("Edite si es Cliente o Empleado:");
                                JOptionPane.showMessageDialog(null, "Eleccion Modificada  ");
                            }
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "No Hay Datos");
                    }
                    break;
                case 5:
                    //anular clientes/empleados del catalogo
                    if (ap2 != -1) {
                        existe = false;
                        buscar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su Numero de registro: "));
                        for (i = 0; i <= ap2; i++) {
                            if (buscar == (Numero[i])) {
                                existe = true;
                                Nombre[i] = "";
                                Edad[i] = 0;
                                activoInactivo[i] = "Inactivo";
                                EmpleadosClientes[i] = " ";
                                ciudad[i] = " ";
                                direccion[i] = " "; 
                                correo[i] = " ";
                            }
                        }
                        if (existe == true) {
                            JOptionPane.showMessageDialog(null, "Eleccion Modificada  ");
                        } else {
                            JOptionPane.showMessageDialog(null, "El Numero de registro " + buscar + " No Existe");
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "No Hay Datos");
                    }
                    break;
                case 6:
                    break;
            }
            //regresar al menu principal
        } while (op != 6);
    } 
  }
  
 

