package proyecto;
import javax.swing.JOptionPane;
public class Menu {
    public void Menu(){   
   byte opcion=0;
   do{
       // menu principal
    Facturacion Factura01=new Facturacion();
      opcion=Byte.parseByte(JOptionPane.showInputDialog(
     "          Menú Principal  \n"
    + "1    Registro de Usuarios\n"
    + "2    Catálogos de empleados/clientes\n"
    + "3    Catalogo de Categorias de Productos\n"             
    + "4    Alquiler de libro y facturación\n"
    + "5    Cajas\n" 
    + "6    Salir\n"         
    + " Elija una opción\n"));
      switch(opcion){
         case 1://usuraios 
            RegistrodeUsuarios registro01=new RegistrodeUsuarios();
            registro01.menuUsuarios();
            break;
         case 2://empleados Clientes
            CatalogoEmpleados catalogo01=new CatalogoEmpleados();
            catalogo01.catalogo();
            break;
         case 3://libros
             CatalogodeCategoriasdeProductos productos01=new CatalogodeCategoriasdeProductos();
             productos01.catalogoCategorias();
             break;
         case 4://facturas
            Factura01.Factura();
            break;
         case 5://cajas
            Factura01.cajas();
            break;
         case 6:
             break;
         default:
            JOptionPane.showMessageDialog(null, "Opción no valida");
            break;  
      }
   }while(opcion!=6);   
   }
}
