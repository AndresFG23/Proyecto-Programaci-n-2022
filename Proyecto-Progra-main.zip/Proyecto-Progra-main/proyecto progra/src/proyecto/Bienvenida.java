package proyecto;

import javax.swing.JOptionPane;
//bienvenida al sistema 
public class Bienvenida {
    public void Bienvenida(){    
        JOptionPane.showMessageDialog(null, "Bienvenid@ a la libreria El Tesoro del Saber \n        "+"     \n          Precione 'ok' para contiunar");
    }
public void gracias(){    
        JOptionPane.showMessageDialog(null, "Gracias por usar el sistema de la libreria El Tesoro del Saber");
    }
}
